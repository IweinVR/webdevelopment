

const setup = () => {
    const staatDropdown = document.getElementById("staat");
    const imgDiv = document.getElementById('img');
    const countDisplay = document.getElementById('count');

    staatDropdown.addEventListener('change', function () {
        let staat = this.value;


        if (staat === 'Met een ei') {
            countDisplay.innerHTML = "Hierboven, een kip met een ei";
        } else if (staat === 'Zonder een ei') {
            countDisplay.innerHTML = "Hierboven, een kip zonder ei";
        } else {


        }



    });


    const zoektekst = document.getElementById("letter").value;


    const letterCount = (tekst.match(new (zoektekst)) || []).length;
    countDisplay.innerHTML = "Letter "+ document.getElementById("letter").value + "komt" +  ${letterCount} + "keer voor in bovenstaande zin.";
}

window.addEventListener("load", setup);
