const setup = () => {
    let review = document.getElementById("knopReview");
    let annuleren = document.getElementById("KnopAnnuleren")
    review.addEventListener("click", review);
    annuleren.addEventListener("click", KnopAnnuleren);

}
const review = () => {
    let review  =document.document.createElement("review");
    review.contains()
}
window.addEventListener("load", setup);